package hackathon;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;
interface Dispatchable {
    double calculateCharge();
    double estimateArrivalMinutes();
}

class InvalidPriorityException extends Exception {
    public InvalidPriorityException(String message) {
        super(message);
    }
}

class NoCallsPendingException extends Exception {
    public NoCallsPendingException(String message) {
        super(message);
    }
}

class CallNotFoundException extends Exception {
    public CallNotFoundException(String message) {
        super(message);
    }
}

class EmergencyCall implements Dispatchable {
    // Mandatory instance variables
    private int callId;
    private String patientName;
    private String location;
    private double distanceKm;
  private int priority;

    // Additional instance variables
    private String callerContact;
    private String callTime;
    private String status;
    private String emergencyType;
    private String hospitalName;
    private boolean governmentScheme;
    private String remarks;

    // Mandatory static variables
    protected static double baseCharge = 500.0;
    protected static double chargePerKm = 20.0;
    protected static double averageSpeedKmph = 40.0;
    protected static int callCount = 0;

    // Additional static variables
    protected static int totalDispatched = 0;
    protected static double totalRevenue = 0.0;
    protected static int nextCallId = 1001;

    // Default constructor
    public EmergencyCall() throws InvalidPriorityException {
        this(nextCallId++, "Unknown", "Not specified", 1.0, 3,
             "Not provided", LocalDateTime.now().toString(),
             "WAITING", "General", "Not assigned", false, "None");
    }

    // Partial constructor
    public EmergencyCall(String patientName, String location,
                         double distanceKm, int priority)
            throws InvalidPriorityException {
        this(nextCallId++, patientName, location, distanceKm, priority,
                "Not provided", LocalDateTime.now().toString(),
                "WAITING", "General", "Not assigned", false, "None");
       }

       // Full constructor (constructor chaining using this)
       public EmergencyCall(int callId, String patientName, String location,
                            double distanceKm, int priority,
                            String callerContact, String callTime,
                            String status, String emergencyType,
                            String hospitalName, boolean governmentScheme,
                            String remarks) throws InvalidPriorityException {
           setCallId(callId);
           setPatientName(patientName);
           setLocation(location);
           setDistanceKm(distanceKm);
           setPriority(priority);
         setPriority(priority);
           setCallerContact(callerContact);
           setCallTime(callTime);
           setStatus(status);
           setEmergencyType(emergencyType);
           setHospitalName(hospitalName);
           setGovernmentScheme(governmentScheme);
           setRemarks(remarks);

           callCount++;
           if (callId >= nextCallId) {
               nextCallId = callId + 1;
           }
       }

       // Getters and setters with validation
       public int getCallId() {
           return callId;
       }

       public void setCallId(int callId) {
           if (callId <= 0) {
               throw new IllegalArgumentException("Call ID must be positive.");
           }
           this.callId = callId;
       }

       public String getPatientName() {
           return patientName;
       }

       public void setPatientName(String patientName) {
           if (patientName == null || patientName.trim().isEmpty()) {
               throw new IllegalArgumentException("Patient name cannot be empty.");
           }
           this.patientName = patientName.trim();
       }

       public String getLocation() {
           return location;
       }

       public void setLocation(String location) {
           if (location == null || location.trim().isEmpty()) {
               throw new IllegalArgumentException("Location cannot be empty.");
           }
           this.location = location.trim();
       }

       public double getDistanceKm() {
           return distanceKm;
       }

       public void setDistanceKm(double distanceKm) {
           if (distanceKm <= 0 || Double.isNaN(distanceKm)
                   || Double.isInfinite(distanceKm)) {
               throw new IllegalArgumentException("Distance must be positive.");
           }
           this.distanceKm = distanceKm;
       }

       public int getPriority() {
           return priority;
       }

       public void setPriority(int priority) throws InvalidPriorityException {
           if (priority < 1 || priority > 3) {
               throw new InvalidPriorityException(
                       "Priority must be between 1 and 3.");
           }
           this.priority = priority;
       }

       public String getCallerContact() {
           return callerContact;
       }

       public void setCallerContact(String callerContact) {
           if (callerContact == null || callerContact.trim().isEmpty()) {
               throw new IllegalArgumentException("Caller contact is required.");
           }
           this.callerContact = callerContact.trim();
       }

       public String getCallTime() {
           return callTime;
       }

       public void setCallTime(String callTime) {
           if (callTime == null || callTime.trim().isEmpty()) {
               throw new IllegalArgumentException("Call time is required.");
           }
           this.callTime = callTime.trim();
       }

       public String getStatus() {
           return status;
       }

       public void setStatus(String status) {
           if (status == null || !(status.equalsIgnoreCase("WAITING")
                 || status.equalsIgnoreCase("DISPATCHED")
                   || status.equalsIgnoreCase("CANCELLED"))) {
               throw new IllegalArgumentException(
                       "Status must be WAITING, DISPATCHED or CANCELLED.");
           }
           this.status = status.toUpperCase();
       }

       public String getEmergencyType() {
           return emergencyType;
       }

       public void setEmergencyType(String emergencyType) {
           if (emergencyType == null || emergencyType.trim().isEmpty()) {
               throw new IllegalArgumentException("Emergency type is required.");
           }
           this.emergencyType = emergencyType.trim();
       }

       public String getHospitalName() {
           return hospitalName;
       }

       public void setHospitalName(String hospitalName) {
           if (hospitalName == null || hospitalName.trim().isEmpty()) {
               throw new IllegalArgumentException("Hospital name is required.");
           }
           this.hospitalName = hospitalName.trim();
       }

       public boolean isGovernmentScheme() {
           return governmentScheme;
       }

       public void setGovernmentScheme(boolean governmentScheme) {
           this.governmentScheme = governmentScheme;
       }

       public String getRemarks() {
           return remarks;
       }

       public void setRemarks(String remarks) {
           if (remarks == null) {
               throw new IllegalArgumentException("Remarks cannot be null.");
           }
           this.remarks = remarks.trim();
       }

       // Method overloading: normal charge and government-scheme charge
       @Override
       public double calculateCharge() {
           return calculateCharge(governmentScheme);
       }

       public double calculateCharge(boolean governmentScheme) {
           double normalCharge = baseCharge + (distanceKm * chargePerKm);

           if (governmentScheme) {
               if (priority == 1) {
                   return 0.0;
               }
               return normalCharge / 2.0;
           }
           return normalCharge;
       }

       @Override
       public double estimateArrivalMinutes() {
           return (distanceKm / averageSpeedKmph) * 60.0;
       }

       // Compare urgency: lower priority number is more urgent.
       // If priorities are equal, shorter distance is more urgent.
       public int compareUrgency(EmergencyCall other) {
           if (this.priority != other.priority) {
               return Integer.compare(this.priority, other.priority);
           }
           return Double.compare(this.distanceKm, other.distanceKm);
       }

       public void display() {
           System.out.println("----------------------------------------");
           System.out.println("Call ID          : " + callId);
           System.out.println("Patient Name     : " + patientName);
           System.out.println("Location         : " + location);
           System.out.println("Distance         : " + distanceKm + " km");
           System.out.println("Priority         : " + priority);
           System.out.println("Caller Contact   : " + callerContact);
           System.out.println("Call Time        : " + callTime);
           System.out.println("Status           : " + status);
           System.out.println("Emergency Type   : " + emergencyType);
           System.out.println("Hospital         : " + hospitalName);
           System.out.println("Government Scheme: " + governmentScheme);
           System.out.println("Remarks          : " + remarks);
           System.out.printf("Estimated Arrival: %.2f minutes%n",
                   estimateArrivalMinutes());
           System.out.printf("Ambulance Charge : Rs. %.2f%n", calculateCharge());
       }

       // Convert an object into one comma-separated file record.
       public String toFileLine() {
           String type = (this instanceof CriticalCall) ? "C" : "E";
           String extra = "";
           if (this instanceof CriticalCall) {
               extra = "," + ((CriticalCall) this).isVentilatorRequired();
           }

           return type + "," + callId + "," + clean(patientName) + ","
                   + clean(location) + "," + distanceKm + "," + priority + ","
                   + clean(callerContact) + "," + clean(callTime) + ","
                   + status + "," + clean(emergencyType) + ","
                   + clean(hospitalName) + "," + governmentScheme + ","
                   + clean(remarks) + extra;
       }

       private String clean(String value) {
           return value.replace(",", " ").replace("\n", " ").trim();
       }

       public static int getCallCount() {
           return callCount;
       }

       public static int getTotalDispatched() {
           return totalDispatched;
       }

       public static double getTotalRevenue() {
           return totalRevenue;
       }
   }

   class CriticalCall extends EmergencyCall {
       // Mandatory child instance variable
	    private boolean ventilatorRequired;

	    // Mandatory child static variables
	    private static double icuCharge = 2500.0;
	    private static double ventilatorCharge = 1500.0;
	    private static double criticalSpeedKmph = 60.0;

	    public CriticalCall() throws InvalidPriorityException {
	        super();
	        setEmergencyType("Critical");
	    }

	    public CriticalCall(String patientName, String location,
	                        double distanceKm, int priority,
	                        boolean ventilatorRequired)
	           throws InvalidPriorityException {
	        super(patientName, location, distanceKm, priority);
	        setEmergencyType("Critical");
	        this.ventilatorRequired = ventilatorRequired;
	    }

	    public CriticalCall(int callId, String patientName, String location,
	                        double distanceKm, int priority,
	                        String callerContact, String callTime,
	                        String status, String emergencyType,
	                        String hospitalName, boolean governmentScheme,
	                        String remarks, boolean ventilatorRequired)
	            throws InvalidPriorityException {
	        super(callId, patientName, location, distanceKm, priority,
	                callerContact, callTime, status, emergencyType,
	                hospitalName, governmentScheme, remarks);
	          this.ventilatorRequired = ventilatorRequired;
	          setEmergencyType("Critical");
	      }

	      public boolean isVentilatorRequired() {
	          return ventilatorRequired;
	      }

	      public void setVentilatorRequired(boolean ventilatorRequired) {
	          this.ventilatorRequired = ventilatorRequired;
	      }

	      // Override parent charge and add ICU and optional ventilator charges.
	      @Override
	      public double calculateCharge() {
	          double parentCharge = super.calculateCharge();
	          double extraCharge = icuCharge;
	          if (ventilatorRequired) {
	              extraCharge += ventilatorCharge;
	          }
	          return parentCharge + extraCharge;
	      }

	      // Critical ambulance uses a faster speed.
	      @Override
	      public double estimateArrivalMinutes() {
	          return (getDistanceKm() / criticalSpeedKmph) * 60.0;
	      }

	      @Override
	      public void display() {
	          super.display();
	          System.out.println("Call Category    : CRITICAL");
	          System.out.println("Ventilator Needed: " + ventilatorRequired);
	     System.out.printf("ICU Charge       : Rs. %.2f%n", icuCharge);
	          if (ventilatorRequired) {
	              System.out.printf("Ventilator Charge: Rs. %.2f%n",
	                      ventilatorCharge);
	          }
	          System.out.printf("Total Critical Charge: Rs. %.2f%n",
	                  calculateCharge());
	      }
	  }

public class RapidResponseApp {
    private static final String DATA_FILE = "calls.csv";
    private static final String LOG_FILE = "dispatched.log";

    // The only collection used: parent type stores parent and child objects.
    private static ArrayList<EmergencyCall> calls =
            new ArrayList<EmergencyCall>();

    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        loadCalls();

        int choice;
        do {
            showMenu();
            choice = readInt("Enter your choice: ");

            try {
                switch (choice) {
                    case 1:
                        addRecord();
                        break;
                    case 2:
                        displayAll();
                        break;
                    case 3:
                        searchById();
                        break;
                    case 4:
                        deleteById();
                        break;
                    case 5:
                        registerEmergencyCall(false);
                        break;
                    case 6:
                        registerEmergencyCall(true);
                        break;
                    case 7:
                        dispatchCall();
                      break;
                    case 8:
                        sortByPriority();
                        break;
                    case 9:
                        showWaiting();
                        break;
                    case 10:
                        longestDistance();
                        break;
                    case 11:
                        showTotalCharges();
                        break;
                    case 12:
                        cancelCall();
                        break;
                    case 13:
                        showSummary();
                        break;
                    case 0:
                        saveCalls();
                        System.out.println("Data saved. Exiting program.");
                        break;
                    default:
                        System.out.println("Invalid menu choice.");
                }
            } catch (InvalidPriorityException | NoCallsPendingException
                     | CallNotFoundException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid input: " + e.getMessage());
            }
        } while (choice != 0);

        sc.close();
    }

    private static void showMenu() {
        System.out.println("\n========== RAPID RESPONSE ==========");
        System.out.println("1. Add a record");
        System.out.println("2. Display all records");
        System.out.println("3. Search record by ID");
        System.out.println("4. Delete record by ID");
        System.out.println("5. Register normal emergency call");
        System.out.println("6. Register critical emergency call");
        System.out.println("7. Dispatch most urgent call");
        System.out.println("8. Sort waiting calls by priority");
        System.out.println("9. Display waiting calls");
        System.out.println("10. Find longest-distance call");
        System.out.println("11. Display total charges");
        System.out.println("12. Cancel a call by ID");
        System.out.println("13. Display system summary");
        System.out.println("0. Save and exit");
        System.out.println("====================================");
    }

    // Requirement: addRecord()
    public static void addRecord()
            throws InvalidPriorityException {
        registerEmergencyCall(false);
    }

    private static void registerEmergencyCall(boolean critical)
            throws InvalidPriorityException {
        System.out.println("\n--- Register Emergency Call ---");
        String name = readLine("Patient name: ");
        String location = readLine("Patient location: ");
        double distance = readDouble("Distance in km: ");
        int priority = readInt("Priority (1 = highest, 2 or 3): ");
        String contact = readLine("Caller contact: ");
        String hospital = readLine("Hospital name: ");
        boolean scheme = readYesNo("Government scheme? (yes/no): ");
        String remarks = readLine("Remarks: ");

        if (critical) {
            boolean ventilator = readYesNo(
                    "Is a ventilator required? (yes/no): ");
            CriticalCall call = new CriticalCall(name, location,
                    distance, priority, ventilator);
            // Set additional details using setters.
            call.setCallerContact(contact);
            call.setHospitalName(hospital);
            call.setGovernmentScheme(scheme);
            call.setRemarks(remarks);
            calls.add(call);
        } else {
            EmergencyCall call = new EmergencyCall(
                    name, location, distance, priority);
            call.setCallerContact(contact);
            call.setHospitalName(hospital);
            call.setGovernmentScheme(scheme);
            call.setRemarks(remarks);
            calls.add(call);
        }

        System.out.println("Call registered successfully.");
    }

    // Requirement: displayAll()
    public static void displayAll() {
      if (calls.isEmpty()) {
            System.out.println("No records available.");
            return;
        }

        for (EmergencyCall call : calls) {
            call.display();
        }
    }
    // Requirement: searchById()
    public static void searchById() throws CallNotFoundException {
        int id = readInt("Enter call ID to search: ");
        EmergencyCall call = findCall(id);
        call.display();
    }

    // Requirement: deleteById()
    public static void deleteById() throws CallNotFoundException {
        int id = readInt("Enter call ID to delete: ");
        EmergencyCall call = findCall(id);
        calls.remove(call);
        System.out.println("Call deleted successfully.");
    }

    private static EmergencyCall findCall(int id)
            throws CallNotFoundException {
        for (EmergencyCall call : calls) {
            if (call.getCallId() == id) {
                return call;
            }
        }
        throw new CallNotFoundException("No call found with ID " + id);
    }

    // Dispatch: smallest priority number first; nearest distance breaks ties.
    public static void dispatchCall() throws NoCallsPendingException {
        EmergencyCall selected = null;

        for (EmergencyCall call : calls) {
            if (call.getStatus().equals("WAITING")) {
                if (selected == null
                        || call.compareUrgency(selected) < 0) {
                    selected = call;
                }
            }
        }

        if (selected == null) {
            throw new NoCallsPendingException(
                    "There are no waiting calls to dispatch.");
        }

        selected.setStatus("DISPATCHED");
        double arrival = selected.estimateArrivalMinutes();
        double charge = selected.calculateCharge();

        EmergencyCall.totalDispatched++;
        EmergencyCall.totalRevenue += charge;

        appendDispatchLog(selected, arrival);

        System.out.println("\nCall dispatched successfully!");
        selected.display();
        System.out.printf("Estimated arrival time: %.2f minutes%n", arrival);
    }

    // Own sorting algorithm: bubble sort, waiting calls first by urgency.
    public static void sortByPriority() {
        for (int i = 0; i < calls.size() - 1; i++) {
            for (int j = 0; j < calls.size() - 1 - i; j++) {
                EmergencyCall first = calls.get(j);
                EmergencyCall second = calls.get(j + 1);

                boolean firstWaiting = first.getStatus().equals("WAITING");
                boolean secondWaiting = second.getStatus().equals("WAITING");

                if ((!firstWaiting && secondWaiting)
                        || (firstWaiting && secondWaiting
                        && first.compareUrgency(second) > 0)) {
                    calls.set(j, second);
                    calls.set(j + 1, first);
                }
            }
        }
        System.out.println("Records sorted. Waiting calls appear first.");
    }

    // Requirement: showWaiting()
    public static void showWaiting() {
        sortByPriority();
        boolean found = false;
        for (EmergencyCall call : calls) {
            if (call.getStatus().equals("WAITING")) {
                call.display();
                found = true;
            }
        }

        if (!found) {
            System.out.println("There are no waiting calls.");
        }
    }

    // Requirement: longestDistance()
    public static void longestDistance() {
        if (calls.isEmpty()) {
            System.out.println("No records available.");
            return;
        }

        EmergencyCall longest = calls.get(0);
        for (EmergencyCall call : calls) {
            if (call.getDistanceKm() > longest.getDistanceKm()) {
                longest = call;
            }
        }

        System.out.println("Call with the longest distance:");
        longest.display();
    }

    public static void showTotalCharges() {
        double total = 0.0;
        for (EmergencyCall call : calls) {
            if (!call.getStatus().equals("CANCELLED")) {
                total += call.calculateCharge();
            }
        }
        System.out.printf("Total charges of non-cancelled calls: Rs. %.2f%n",
                total);
        System.out.printf("Revenue from dispatched calls: Rs. %.2f%n",
                EmergencyCall.getTotalRevenue());
    }

    private static void cancelCall()
            throws CallNotFoundException {
        int id = readInt("Enter call ID to cancel: ");
        EmergencyCall call = findCall(id);

        if (call.getStatus().equals("DISPATCHED")) {
            System.out.println("A dispatched call cannot be cancelled.");
            return;
        }

        call.setStatus("CANCELLED");
        System.out.println("Call cancelled successfully.");
    }
    private static void showSummary() {
        int waiting = 0;
        int dispatched = 0;
        int cancelled = 0;
        int critical = 0;

        for (EmergencyCall call : calls) {
            if (call.getStatus().equals("WAITING")) {
                waiting++;
            } else if (call.getStatus().equals("DISPATCHED")) {
                dispatched++;
            } else if (call.getStatus().equals("CANCELLED")) {
                cancelled++;
            }

            if (call instanceof CriticalCall) {
                critical++;
            }
        }

        System.out.println("\n---------- SYSTEM SUMMARY ----------");
        System.out.println("Total records loaded/registered: " + calls.size());
        System.out.println("Waiting calls                  : " + waiting);
        System.out.println("Dispatched calls               : " + dispatched);
        System.out.println("Cancelled calls                : " + cancelled);
        System.out.println("Critical calls                 : " + critical);
        System.out.println("Total objects constructed      : "
                + EmergencyCall.getCallCount());
        System.out.println("Total dispatches this run      : "
                + EmergencyCall.getTotalDispatched());
        System.out.printf("Revenue this run               : Rs. %.2f%n",
                EmergencyCall.getTotalRevenue());
        System.out.println("------------------------------------");
    }

    // Save all records, one record per line.
    public static void saveCalls() {
        try (BufferedWriter writer =
                     new BufferedWriter(new FileWriter(DATA_FILE))) {
            for (EmergencyCall call : calls) {
                writer.write(call.toFileLine());
                writer.newLine();
            }
            System.out.println("Records saved to " + DATA_FILE);
        } catch (IOException e) {
            System.out.println("Unable to save records: " + e.getMessage());
        }
    }

    // Load records. A missing file on first run is normal.
  public static void loadCalls() {
        try (BufferedReader reader =
                     new BufferedReader(new FileReader(DATA_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue;
                }

                try {
                    String[] p = line.split(",", -1);
                    if (p.length < 13) {
                        throw new IllegalArgumentException(
                                "Incomplete record.");
                    }

                    String type = p[0];
                    int id = Integer.parseInt(p[1]);
                    String name = p[2];
                    String location = p[3];
                    double distance = Double.parseDouble(p[4]);
                    int priority = Integer.parseInt(p[5]);
                    String contact = p[6];
                    String time = p[7];
                    String status = p[8];
                    String emergencyType = p[9];
                    String hospital = p[10];
                    boolean scheme = Boolean.parseBoolean(p[11]);
                    String remarks = p[12];

                    EmergencyCall call;
                    if (type.equalsIgnoreCase("C")) {
                        if (p.length < 14) {
                            throw new IllegalArgumentException(
                                    "Critical record is incomplete.");
                        }
                        boolean ventilator = Boolean.parseBoolean(p[13]);
                        call = new CriticalCall(id, name, location,
                                distance, priority, contact, time, status,
                                emergencyType, hospital, scheme, remarks,
                                ventilator);
                    } else if (type.equalsIgnoreCase("E")) {
                        call = new EmergencyCall(id, name, location,
                                distance, priority, contact, time, status,
                                emergencyType, hospital, scheme, remarks);
                    } else {
                        throw new IllegalArgumentException(
                                "Unknown record type.");
                    }

                    calls.add(call);
                } catch (Exception damagedLine) {
                    // Ignore one damaged line and continue loading.
                    System.out.println("Skipped damaged record: "
                            + damagedLine.getMessage());
                }
            }
            System.out.println("Previous records loaded: " + calls.size());
        } catch (java.io.FileNotFoundException e) {
            // First run: no file exists, so start with an empty list.
            System.out.println("No previous data file. Starting a new register.");
        } catch (IOException e) {
            System.out.println("Error reading records: " + e.getMessage());
        }
    }

    // Each dispatch is appended; previous log entries are preserved.
    private static void appendDispatchLog(EmergencyCall call,
                                         double arrivalMinutes) {
        try (BufferedWriter writer =
                     new BufferedWriter(new FileWriter(LOG_FILE, true))) {
            writer.write("Call ID: " + call.getCallId()
                    + " | Patient: " + call.getPatientName()
                    + " | Priority: " + call.getPriority()
                    + " | Estimated arrival: "
                    + String.format("%.2f", arrivalMinutes) + " minutes"
                    + " | Dispatched at: "
                    + LocalDateTime.now().format(
                            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Unable to update dispatch log: "
                    + e.getMessage());
        }
    }

    // Input helper methods
    private static String readLine(String message) {
        System.out.print(message);
        return sc.nextLine().trim();
    }

    private static int readInt(String message) {
        while (true) {
            try {
                System.out.print(message);
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid whole number.");
            }
        }
    }

    private static double readDouble(String message) {
        while (true) {
            try {
                System.out.print(message);
                return Double.parseDouble(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    private static boolean readYesNo(String message) {
        while (true) {
            String answer = readLine(message);
            if (answer.equalsIgnoreCase("yes")
                    || answer.equalsIgnoreCase("y")) {
                return true;
            }
            if (answer.equalsIgnoreCase("no")
                    || answer.equalsIgnoreCase("n")) {
                return false;
            }
            System.out.println("Please enter yes or no.");
        }
    }

}
